import React, { useState, useEffect } from 'react';
import { GameConfig, MatchType, Player } from '../types';
import { saveMatch } from '../services/storageService';
import { RotateCcw, Save } from 'lucide-react';

interface MatchInterfaceProps {
  config: GameConfig;
  onFinish: () => void;
}

export const MatchInterface: React.FC<MatchInterfaceProps> = ({ config, onFinish }) => {
  const [scoreA, setScoreA] = useState(0);
  const [scoreB, setScoreB] = useState(0);
  const [history, setHistory] = useState<{a: number, b: number}[]>([]);
  
  // Service State
  const [currentServerIndex, setCurrentServerIndex] = useState(config.initialServerIndex);
  const [servesLeft, setServesLeft] = useState(2); 

  const isDeuce = scoreA >= 10 && scoreB >= 10;
  const isWinnerA = scoreA >= 11 && scoreA >= scoreB + 2;
  const isWinnerB = scoreB >= 11 && scoreB >= scoreA + 2;
  const isGameOver = isWinnerA || isWinnerB;

  const currentServer = config.serviceOrder[currentServerIndex];

  const handleScore = (team: 'A' | 'B') => {
    if (isGameOver) return;

    // Save history for undo
    setHistory(prev => [...prev, { a: scoreA, b: scoreB }]);
    
    let newScoreA = scoreA;
    let newScoreB = scoreB;

    if (team === 'A') {
      newScoreA++;
      setScoreA(newScoreA);
    } else {
      newScoreB++;
      setScoreB(newScoreB);
    }

    // Check Service Rotation
    const nextDeuce = newScoreA >= 10 && newScoreB >= 10;
    
    let nextServesLeft = servesLeft - 1;
    
    if (nextServesLeft <= 0) {
      rotateServer();
      setServesLeft(nextDeuce ? 1 : 2);
    } else {
      setServesLeft(nextServesLeft);
    }
  };

  const rotateServer = () => {
    setCurrentServerIndex(prev => (prev + 1) % config.serviceOrder.length);
  };

  const undo = () => {
    if (history.length === 0) return;
    const lastState = history[history.length - 1];
    setHistory(prev => prev.slice(0, -1));
    setScoreA(lastState.a);
    setScoreB(lastState.b);
    
    recalculateServiceState(lastState.a, lastState.b);
  };

  const recalculateServiceState = (sA: number, sB: number) => {
    const totalPoints = sA + sB;
    let sIdx = config.initialServerIndex;
    let currentServes = 2;
    
    for (let i = 0; i < totalPoints; i++) {
        currentServes--;
        if (currentServes === 0) {
            sIdx = (sIdx + 1) % config.serviceOrder.length;
            // If total points after this point (i+1) is >= 20, we are in deuce rotation (1 serve)
            // Otherwise standard rotation (2 serves)
            if (i + 1 >= 20) {
                currentServes = 1;
            } else {
                currentServes = 2;
            }
        }
    }
    
    setCurrentServerIndex(sIdx);
    setServesLeft(currentServes);
  };

  const handleFinish = () => {
    saveMatch({
      type: config.type,
      teamA: config.teamA.map(p => p.id),
      teamB: config.teamB.map(p => p.id),
      scoreA,
      scoreB,
      winnerTeam: scoreA > scoreB ? 'A' : 'B'
    });
    onFinish();
  };

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-6 bg-white p-4 rounded-lg shadow">
        <div className="text-sm text-gray-500 font-mono">
           {config.type === MatchType.SINGLES ? 'SINGULAR' : 'PARES'} | SERVIÇO: {currentServer?.name} ({servesLeft})
        </div>
        <div className="flex gap-2">
           <button 
             onClick={undo} 
             disabled={history.length === 0 || isGameOver} 
             className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
           >
             <RotateCcw size={18} />
             <span>Desfazer</span>
           </button>
        </div>
      </div>

      {/* Scoreboard Area */}
      <div className="flex-1 grid grid-cols-2 gap-4 md:gap-8">
        
        {/* Team A */}
        <div 
          onClick={() => handleScore('A')}
          className={`relative cursor-pointer flex flex-col items-center justify-center p-6 rounded-2xl transition-all transform active:scale-95 ${
            isWinnerA ? 'bg-green-100 ring-4 ring-green-500' : 'bg-white hover:bg-blue-50'
          } shadow-xl border-2 ${
            // Highlight if current server is in this team
            config.teamA.some(p => p.id === currentServer.id) ? 'border-orange-400' : 'border-transparent'
          }`}
        >
          {/* Service Indicator Badge */}
          {config.teamA.some(p => p.id === currentServer.id) && (
             <div className="absolute top-4 right-4 bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full animate-pulse shadow-sm">
               A SERVIR
             </div>
          )}

          <div className="text-9xl md:text-[12rem] font-bold text-gray-800 leading-none select-none">
            {scoreA}
          </div>
          
          <div className="mt-8 flex flex-col items-center gap-4">
            <div className="flex gap-4">
              {config.teamA.map(p => (
                <div key={p.id} className={`flex flex-col items-center p-2 rounded-lg ${currentServer.id === p.id ? 'bg-orange-100 ring-2 ring-orange-500' : ''}`}>
                   <img src={p.photoUrl} alt={p.name} className="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover border-2 border-white shadow-sm" />
                   <span className="font-semibold mt-2 text-center text-sm md:text-base">{p.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Team B */}
        <div 
          onClick={() => handleScore('B')}
          className={`relative cursor-pointer flex flex-col items-center justify-center p-6 rounded-2xl transition-all transform active:scale-95 ${
            isWinnerB ? 'bg-green-100 ring-4 ring-green-500' : 'bg-white hover:bg-red-50'
          } shadow-xl border-2 ${
            config.teamB.some(p => p.id === currentServer.id) ? 'border-orange-400' : 'border-transparent'
          }`}
        >
           {/* Service Indicator Badge */}
           {config.teamB.some(p => p.id === currentServer.id) && (
             <div className="absolute top-4 right-4 bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full animate-pulse shadow-sm">
               A SERVIR
             </div>
          )}

          <div className="text-9xl md:text-[12rem] font-bold text-gray-800 leading-none select-none">
            {scoreB}
          </div>

          <div className="mt-8 flex flex-col items-center gap-4">
            <div className="flex gap-4">
              {config.teamB.map(p => (
                <div key={p.id} className={`flex flex-col items-center p-2 rounded-lg ${currentServer.id === p.id ? 'bg-orange-100 ring-2 ring-orange-500' : ''}`}>
                   <img src={p.photoUrl} alt={p.name} className="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover border-2 border-white shadow-sm" />
                   <span className="font-semibold mt-2 text-center text-sm md:text-base">{p.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Game Over Actions */}
      {isGameOver && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white p-8 rounded-xl shadow-2xl max-w-md w-full text-center">
            <h2 className="text-3xl font-bold mb-2">Jogo Terminado!</h2>
            <p className="text-xl text-gray-600 mb-6">
              Vencedor: <span className="font-bold text-blue-600">{isWinnerA ? 'Equipa A' : 'Equipa B'}</span>
            </p>
            <div className="flex gap-4 justify-center">
              <button onClick={undo} className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 font-semibold">
                Corrigir (Undo)
              </button>
              <button onClick={handleFinish} className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold flex items-center gap-2">
                <Save size={20} /> Guardar & Sair
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};