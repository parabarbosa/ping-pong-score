import React, { useEffect, useState } from 'react';
import { Player, MatchResult } from '../types';
import { getPlayers, getMatches } from '../services/storageService';
import { TrendingUp, Activity } from 'lucide-react';

interface HistoryPoint {
  month: string; // "Jan 24"
  sortKey: string; // "2024-01" for sorting
  value: number;
}

interface PlayerHistory {
  playerId: string;
  name: string;
  color: string;
  data: HistoryPoint[];
}

export const Leaderboard: React.FC = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const [historyData, setHistoryData] = useState<PlayerHistory[]>([]);
  const [metric, setMetric] = useState<'WIN_RATE' | 'POINT_BALANCE'>('WIN_RATE');

  const COLORS = ['#2563eb', '#dc2626', '#16a34a', '#d97706', '#9333ea'];

  useEffect(() => {
    const playerData = getPlayers();
    const matchData = getMatches();
    
    // Sort Players for Table
    const sortedPlayers = [...playerData].sort((a, b) => {
      if (b.stats.matchesWon !== a.stats.matchesWon) {
        return b.stats.matchesWon - a.stats.matchesWon;
      }
      return (b.stats.pointsWon - b.stats.pointsLost) - (a.stats.pointsWon - a.stats.pointsLost);
    });
    
    setPlayers(sortedPlayers);
    setMatches(matchData);

    // Calculate History for Top 5 Players
    if (matchData.length > 0) {
      calculateHistory(sortedPlayers.slice(0, 5), matchData);
    }
  }, [metric]); // Re-calc when metric changes

  const calculateHistory = (topPlayers: Player[], allMatches: MatchResult[]) => {
    // 1. Identify all unique months in data
    const sortedMatches = [...allMatches].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    if (sortedMatches.length === 0) return;

    const monthsSet = new Set<string>();
    sortedMatches.forEach(m => {
      const d = new Date(m.date);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthsSet.add(key);
    });
    const months = Array.from(monthsSet).sort();

    // 2. Build cumulative stats per player per month
    const history: PlayerHistory[] = topPlayers.map((p, idx) => ({
      playerId: p.id,
      name: p.name,
      color: COLORS[idx % COLORS.length],
      data: []
    }));

    history.forEach(h => {
      let cumulativeWins = 0;
      let cumulativePlayed = 0;
      let cumulativePointsWon = 0;
      let cumulativePointsLost = 0;

      h.data = months.map(monthKey => {
        // Find matches up to and including this month
        // Ideally, we process sequentially, but filter is safer for logic simplicity
        const matchesInMonth = sortedMatches.filter(m => {
           const d = new Date(m.date);
           const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
           return k === monthKey;
        });

        // Update cumulatives based on matches IN THIS MONTH
        matchesInMonth.forEach(m => {
          const isTeamA = m.teamA.includes(h.playerId);
          const isTeamB = m.teamB.includes(h.playerId);
          
          if (isTeamA || isTeamB) {
            cumulativePlayed++;
            
            if (isTeamA) {
              if (m.winnerTeam === 'A') cumulativeWins++;
              cumulativePointsWon += m.scoreA;
              cumulativePointsLost += m.scoreB;
            } else {
              if (m.winnerTeam === 'B') cumulativeWins++;
              cumulativePointsWon += m.scoreB;
              cumulativePointsLost += m.scoreA;
            }
          }
        });

        // Calculate Metric Value
        let val = 0;
        if (metric === 'WIN_RATE') {
           val = cumulativePlayed > 0 ? Math.round((cumulativeWins / cumulativePlayed) * 100) : 0;
        } else {
           val = cumulativePointsWon - cumulativePointsLost;
        }

        // Format label
        const [y, m] = monthKey.split('-');
        const label = `${m}/${y.slice(2)}`;

        return {
          month: label,
          sortKey: monthKey,
          value: val
        };
      });
    });

    setHistoryData(history);
  };

  // --- SVG Chart Helper ---
  const renderChart = () => {
    if (historyData.length === 0 || historyData[0].data.length === 0) return (
      <div className="h-64 flex items-center justify-center text-gray-400 border rounded-lg bg-gray-50">
        Sem dados históricos suficientes para gerar gráfico.
      </div>
    );

    const dataPointsCount = historyData[0].data.length;
    const width = 800;
    const height = 300;
    const padding = 40;

    // Calculate Min/Max Y
    let allValues: number[] = [];
    historyData.forEach(p => p.data.forEach(d => allValues.push(d.value)));
    
    let maxY = Math.max(...allValues);
    let minY = Math.min(...allValues);
    
    // Add some buffer
    if (metric === 'WIN_RATE') {
      maxY = 100;
      minY = 0;
    } else {
      const range = maxY - minY || 10;
      maxY += range * 0.1;
      minY -= range * 0.1;
    }

    const getX = (index: number) => padding + (index * ((width - padding * 2) / (dataPointsCount - 1 || 1)));
    const getY = (val: number) => height - padding - ((val - minY) / (maxY - minY || 1)) * (height - padding * 2);

    return (
      <div className="bg-white p-4 rounded-lg shadow border overflow-x-auto">
         <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto min-w-[600px]">
            {/* Grid Lines */}
            <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#e5e7eb" />
            <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#e5e7eb" />
            <line x1={padding} y1={height / 2} x2={width - padding} y2={height / 2} stroke="#f3f4f6" strokeDasharray="4" />

            {/* Y Axis Labels */}
            <text x={padding - 10} y={getY(maxY)} textAnchor="end" className="text-xs fill-gray-400">{Math.round(maxY)}</text>
            <text x={padding - 10} y={getY(minY)} textAnchor="end" className="text-xs fill-gray-400">{Math.round(minY)}</text>

            {/* X Axis Labels */}
            {historyData[0].data.map((point, i) => (
               <text key={i} x={getX(i)} y={height - 10} textAnchor="middle" className="text-xs fill-gray-500 font-medium">
                 {point.month}
               </text>
            ))}

            {/* Lines */}
            {historyData.map((player) => {
               const points = player.data.map((d, i) => `${getX(i)},${getY(d.value)}`).join(' ');
               return (
                 <g key={player.playerId}>
                   <polyline
                     points={points}
                     fill="none"
                     stroke={player.color}
                     strokeWidth="3"
                     strokeLinecap="round"
                     strokeLinejoin="round"
                     className="transition-all duration-500 ease-in-out hover:stroke-width-4"
                   />
                   {/* Dots */}
                   {player.data.map((d, i) => (
                     <circle 
                       key={i} 
                       cx={getX(i)} 
                       cy={getY(d.value)} 
                       r="4" 
                       fill="white" 
                       stroke={player.color} 
                       strokeWidth="2"
                     />
                   ))}
                 </g>
               );
            })}
         </svg>
         
         {/* Legend */}
         <div className="flex flex-wrap gap-4 mt-4 justify-center">
            {historyData.map(p => (
              <div key={p.playerId} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: p.color }}></div>
                <span className="text-sm text-gray-700 font-medium">{p.name}</span>
              </div>
            ))}
         </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      
      {/* Evolution Section */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <TrendingUp className="text-blue-600" />
            Evolução Mensal (Top 5)
          </h2>
          <div className="bg-gray-200 p-1 rounded-lg flex text-sm font-medium">
             <button 
               onClick={() => setMetric('WIN_RATE')}
               className={`px-4 py-1.5 rounded-md transition-all ${metric === 'WIN_RATE' ? 'bg-white shadow text-blue-700' : 'text-gray-600 hover:text-gray-900'}`}
             >
               % Vitórias
             </button>
             <button 
               onClick={() => setMetric('POINT_BALANCE')}
               className={`px-4 py-1.5 rounded-md transition-all ${metric === 'POINT_BALANCE' ? 'bg-white shadow text-blue-700' : 'text-gray-600 hover:text-gray-900'}`}
             >
               Saldo Pontos
             </button>
          </div>
        </div>
        
        {renderChart()}
      </section>

      {/* Table Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
           <Activity className="text-orange-500" />
           Tabela Geral
        </h2>
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="p-4 font-semibold text-gray-600">Pos</th>
                  <th className="p-4 font-semibold text-gray-600">Jogador</th>
                  <th className="p-4 font-semibold text-gray-600 text-center">Jogos</th>
                  <th className="p-4 font-semibold text-gray-600 text-center">V / D</th>
                  <th className="p-4 font-semibold text-gray-600 text-center">Win Rate</th>
                  <th className="p-4 font-semibold text-gray-600 text-right">Saldo Pontos</th>
                </tr>
              </thead>
              <tbody>
                {players.map((player, index) => {
                  const winRate = player.stats.matchesPlayed > 0 
                    ? Math.round((player.stats.matchesWon / player.stats.matchesPlayed) * 100) 
                    : 0;
                  
                  return (
                    <tr key={player.id} className="border-b hover:bg-gray-50">
                      <td className="p-4">
                        <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full font-bold ${
                          index === 0 ? 'bg-yellow-100 text-yellow-700' : 
                          index === 1 ? 'bg-gray-100 text-gray-700' :
                          index === 2 ? 'bg-orange-100 text-orange-700' : 'text-gray-500'
                        }`}>
                          {index + 1}
                        </span>
                      </td>
                      <td className="p-4 flex items-center gap-3">
                        <img src={player.photoUrl} alt="" className="w-10 h-10 rounded-full object-cover bg-gray-200" />
                        <span className="font-medium">{player.name}</span>
                      </td>
                      <td className="p-4 text-center">{player.stats.matchesPlayed}</td>
                      <td className="p-4 text-center">
                        <span className="text-green-600 font-bold">{player.stats.matchesWon}</span>
                        <span className="text-gray-400 mx-1">/</span>
                        <span className="text-red-600 font-bold">{player.stats.matchesLost}</span>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500" style={{ width: `${winRate}%` }}></div>
                          </div>
                          <span className="text-xs text-gray-500">{winRate}%</span>
                        </div>
                      </td>
                      <td className="p-4 text-right font-mono">
                        {player.stats.pointsWon - player.stats.pointsLost > 0 ? '+' : ''}
                        {player.stats.pointsWon - player.stats.pointsLost}
                      </td>
                    </tr>
                  );
                })}
                {players.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-gray-500">Sem dados para mostrar.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};