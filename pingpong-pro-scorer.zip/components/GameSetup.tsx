import React, { useState, useEffect } from 'react';
import { Player, GameConfig, MatchType } from '../types';
import { getPlayers } from '../services/storageService';
import { User, Users } from 'lucide-react';

interface GameSetupProps {
  onStart: (config: GameConfig) => void;
  onCancel: () => void;
}

export const GameSetup: React.FC<GameSetupProps> = ({ onStart, onCancel }) => {
  const [mode, setMode] = useState<MatchType | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  
  // Selections
  const [selectedPlayers, setSelectedPlayers] = useState<(string | '')[]>([]); // Indexes map to slots
  const [step, setStep] = useState<'MODE' | 'PLAYERS' | 'SERVER'>('MODE');
  
  // Server Selection State
  const [servingTeam, setServingTeam] = useState<'A' | 'B' | null>(null);

  useEffect(() => {
    setPlayers(getPlayers());
  }, []);

  const handleModeSelect = (m: MatchType) => {
    setMode(m);
    // Initialize slots: 2 for singles, 4 for doubles
    const slots = m === MatchType.SINGLES ? ['', ''] : ['', '', '', ''];
    setSelectedPlayers(slots);
    setStep('PLAYERS');
  };

  const handlePlayerSelect = (index: number, playerId: string) => {
    const newSelected = [...selectedPlayers];
    newSelected[index] = playerId;
    setSelectedPlayers(newSelected);
  };

  const validatePlayers = () => {
    return selectedPlayers.every(id => id !== '') && new Set(selectedPlayers).size === selectedPlayers.length;
  };

  const getSlotLabel = (index: number) => {
    if (mode === MatchType.SINGLES) {
      return index === 0 ? 'Jogador A' : 'Jogador B';
    } else {
      // 0,2 = Team A. 1,3 = Team B in rotation logic, but physically on table:
      // Left Side (Team A): Slot 0, Slot 1 (in local array logic for UI)
      // Right Side (Team B): Slot 2, Slot 3
      // Let's map clearly in the UI render
      return `Jogador ${index + 1}`;
    }
  };

  const handleStartGame = (initialPlayerIndex: number) => {
    if (!mode) return;

    // Map selection to Team objects
    // Singles: [P1, P2] -> TeamA=[P1], TeamB=[P2]
    // Doubles: [A1, A2, B1, B2] (from UI inputs) -> TeamA=[A1,A2], TeamB=[B1,B2]
    
    let teamA: Player[] = [];
    let teamB: Player[] = [];
    let serviceOrder: Player[] = [];
    let initialServerIdx = 0;

    const getP = (idx: number) => players.find(p => p.id === selectedPlayers[idx])!;

    if (mode === MatchType.SINGLES) {
      const p1 = getP(0);
      const p2 = getP(1);
      teamA = [p1];
      teamB = [p2];
      // Rotation: P1, P2
      serviceOrder = [p1, p2];
      // If P2 (index 1 in selection) is chosen to serve, index in serviceOrder is 1
      initialServerIdx = initialPlayerIndex; 
    } else {
      // Doubles Logic
      // UI Slots: 0: A1, 1: A2, 2: B1, 3: B2 (Based on visual layout below)
      
      const a1 = getP(0);
      const a2 = getP(1);
      const b1 = getP(2);
      const b2 = getP(3);
      
      teamA = [a1, a2];
      teamB = [b1, b2];

      // Doubles Rotation Sequence logic as per prompt:
      // "Service rotates sequentially through the 4 players"
      // Order depends on who starts.
      // If A1 starts: A1 -> B1 -> A2 -> B2 (Standard rotation pattern)
      // If A2 starts: A2 -> B1 -> A1 -> B2 ?? 
      // Simplified Sequential: Team A Player X -> Team B Player Y -> Team A Player Z -> Team B Player W.
      
      // Let's construct the rotation array based on the starting player.
      // We need to identify the "Starting Player" from the UI click.
      
      const starterId = selectedPlayers[initialPlayerIndex]; // The specific player clicked
      const isTeamAStart = teamA.some(p => p.id === starterId);
      
      const startTeam = isTeamAStart ? teamA : teamB;
      const secondTeam = isTeamAStart ? teamB : teamA;
      
      const pStart = startTeam.find(p => p.id === starterId)!;
      const pStartPartner = startTeam.find(p => p.id !== starterId)!;
      
      // We need a deterministic order. 
      // Let's assume standard: Server -> Receiver -> Server's Partner -> Receiver's Partner.
      // But we don't pick a receiver explicitly in this simple UI.
      // Prompt says: "Seleção jogador serve primeiro".
      // Let's just alternate teams.
      // Order: [Starter, Opponent1, StarterPartner, Opponent2]
      
      serviceOrder = [
        pStart,
        secondTeam[0], // Arbitrary opponent first
        pStartPartner,
        secondTeam[1]
      ];
      
      initialServerIdx = 0; // Always 0 because we constructed the array starting with them.
    }

    onStart({
      type: mode,
      teamA,
      teamB,
      initialServerIndex: initialServerIdx,
      serviceOrder
    });
  };

  // --- RENDERERS ---

  if (step === 'MODE') {
    return (
      <div className="flex flex-col gap-6 max-w-lg mx-auto mt-10">
        <h2 className="text-2xl font-bold text-center">Selecionar Modo de Jogo</h2>
        <button onClick={() => handleModeSelect(MatchType.SINGLES)} className="p-8 bg-white border-2 border-blue-100 hover:border-blue-500 rounded-xl shadow-sm flex flex-col items-center gap-4 transition-all">
          <User size={48} className="text-blue-600" />
          <span className="text-xl font-bold">Individual (1 vs 1)</span>
        </button>
        <button onClick={() => handleModeSelect(MatchType.DOUBLES)} className="p-8 bg-white border-2 border-purple-100 hover:border-purple-500 rounded-xl shadow-sm flex flex-col items-center gap-4 transition-all">
          <Users size={48} className="text-purple-600" />
          <span className="text-xl font-bold">Pares (2 vs 2)</span>
        </button>
        <button onClick={onCancel} className="text-gray-500 underline">Voltar</button>
      </div>
    );
  }

  // --- SINGLES SETUP ---
  if (step === 'PLAYERS' && mode === MatchType.SINGLES) {
    return (
      <div className="max-w-xl mx-auto mt-10 space-y-8">
        <h2 className="text-2xl font-bold text-center">Quem vai jogar?</h2>
        
        <div className="grid grid-cols-2 gap-8">
            {[0, 1].map(idx => (
                <div key={idx} className="space-y-2">
                    <label className="block font-semibold text-gray-700">Jogador {idx + 1}</label>
                    <select 
                        value={selectedPlayers[idx]} 
                        onChange={(e) => handlePlayerSelect(idx, e.target.value)}
                        className="w-full p-3 border rounded-lg bg-white"
                    >
                        <option value="">Selecionar...</option>
                        {players.filter(p => !selectedPlayers.includes(p.id) || selectedPlayers[idx] === p.id).map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>
            ))}
        </div>

        {validatePlayers() && (
             <div className="bg-blue-50 p-6 rounded-lg text-center">
                 <h3 className="text-lg font-bold mb-4 text-blue-900">Quem serve primeiro?</h3>
                 <div className="flex justify-center gap-4">
                     {[0, 1].map(idx => {
                         const p = players.find(x => x.id === selectedPlayers[idx]);
                         if(!p) return null;
                         return (
                            <button key={idx} onClick={() => handleStartGame(idx)} className="flex flex-col items-center p-4 bg-white border hover:bg-blue-100 rounded-lg transition-colors">
                                <img src={p.photoUrl} className="w-16 h-16 rounded-full mb-2 object-cover" alt={p.name} />
                                <span className="font-semibold">{p.name}</span>
                            </button>
                         )
                     })}
                 </div>
             </div>
        )}
        <button onClick={onCancel} className="w-full py-3 text-gray-500">Cancelar</button>
      </div>
    );
  }

  // --- DOUBLES SETUP ---
  if (step === 'PLAYERS' && mode === MatchType.DOUBLES) {
      
    // Slots 0,1 = Team A. Slots 2,3 = Team B.
    const isPlayersComplete = validatePlayers();

    return (
      <div className="max-w-4xl mx-auto mt-6">
         <h2 className="text-2xl font-bold text-center mb-6">Configuração de Pares</h2>
         
         {/* Visual Table */}
         <div className="relative bg-green-600 rounded-lg shadow-xl p-8 mb-8 aspect-video flex">
            {/* Net */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-white/50 transform -translate-x-1/2 z-10"></div>
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/30 transform -translate-y-1/2"></div>
            
            {/* Left Side (Team A) */}
            <div className="flex-1 flex flex-col justify-center gap-4 pr-8 border-r-2 border-white/20">
                <div className="bg-white/90 p-3 rounded shadow-lg">
                    <div className="text-xs font-bold text-gray-500 mb-1">EQUIPA A - JOGADOR 1</div>
                    <select 
                        value={selectedPlayers[0]} 
                        onChange={(e) => handlePlayerSelect(0, e.target.value)}
                        className="w-full p-2 border rounded"
                    >
                        <option value="">Selecionar...</option>
                        {players.filter(p => !selectedPlayers.includes(p.id) || selectedPlayers[0] === p.id).map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>
                <div className="bg-white/90 p-3 rounded shadow-lg">
                    <div className="text-xs font-bold text-gray-500 mb-1">EQUIPA A - JOGADOR 2</div>
                    <select 
                        value={selectedPlayers[1]} 
                        onChange={(e) => handlePlayerSelect(1, e.target.value)}
                        className="w-full p-2 border rounded"
                    >
                        <option value="">Selecionar...</option>
                        {players.filter(p => !selectedPlayers.includes(p.id) || selectedPlayers[1] === p.id).map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>
            </div>

            {/* Right Side (Team B) */}
            <div className="flex-1 flex flex-col justify-center gap-4 pl-8">
                 <div className="bg-white/90 p-3 rounded shadow-lg">
                    <div className="text-xs font-bold text-gray-500 mb-1">EQUIPA B - JOGADOR 1</div>
                    <select 
                        value={selectedPlayers[2]} 
                        onChange={(e) => handlePlayerSelect(2, e.target.value)}
                        className="w-full p-2 border rounded"
                    >
                        <option value="">Selecionar...</option>
                        {players.filter(p => !selectedPlayers.includes(p.id) || selectedPlayers[2] === p.id).map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>
                <div className="bg-white/90 p-3 rounded shadow-lg">
                    <div className="text-xs font-bold text-gray-500 mb-1">EQUIPA B - JOGADOR 2</div>
                    <select 
                        value={selectedPlayers[3]} 
                        onChange={(e) => handlePlayerSelect(3, e.target.value)}
                        className="w-full p-2 border rounded"
                    >
                        <option value="">Selecionar...</option>
                        {players.filter(p => !selectedPlayers.includes(p.id) || selectedPlayers[3] === p.id).map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>
            </div>
         </div>

         {/* Steps for Serving */}
         {isPlayersComplete && !servingTeam && (
             <div className="text-center space-y-4 animate-fade-in">
                 <h3 className="text-xl font-bold">Que equipa começa a servir?</h3>
                 <div className="flex justify-center gap-4">
                     <button onClick={() => setServingTeam('A')} className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-bold">
                         Equipa A
                     </button>
                     <button onClick={() => setServingTeam('B')} className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-bold">
                         Equipa B
                     </button>
                 </div>
             </div>
         )}

         {isPlayersComplete && servingTeam && (
             <div className="text-center space-y-4 animate-fade-in">
                 <h3 className="text-xl font-bold">Qual jogador da Equipa {servingTeam} serve primeiro?</h3>
                 <div className="flex justify-center gap-4">
                     {(servingTeam === 'A' ? [0, 1] : [2, 3]).map(idx => {
                          const p = players.find(x => x.id === selectedPlayers[idx]);
                          if(!p) return null;
                          return (
                             <button key={idx} onClick={() => handleStartGame(idx)} className="flex flex-col items-center p-4 bg-white border-2 border-blue-500 hover:bg-blue-50 rounded-lg transition-colors shadow-lg transform hover:scale-105">
                                 <img src={p.photoUrl} className="w-20 h-20 rounded-full mb-2 object-cover" alt={p.name} />
                                 <span className="font-semibold">{p.name}</span>
                             </button>
                          )
                     })}
                 </div>
                 <button onClick={() => setServingTeam(null)} className="text-sm text-gray-500 mt-4 underline">Voltar à escolha de equipa</button>
             </div>
         )}
         
         <div className="mt-8 text-center">
            <button onClick={onCancel} className="text-gray-500">Cancelar Configuração</button>
         </div>
      </div>
    );
  }

  return null;
};
