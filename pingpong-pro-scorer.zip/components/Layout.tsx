import React from 'react';
import { ViewState } from '../types';
import { Trophy, Users, Play, BarChart2 } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentView, setView }) => {
  const navItems = [
    { id: 'MENU', icon: Play, label: 'Novo Jogo', view: 'MENU' as ViewState },
    { id: 'PLAYERS', icon: Users, label: 'Jogadores', view: 'PLAYERS' as ViewState },
    { id: 'LEADERBOARD', icon: Trophy, label: 'Ranking', view: 'LEADERBOARD' as ViewState },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Nav */}
      <nav className="md:hidden bg-blue-800 text-white p-4 flex justify-around sticky top-0 z-50 shadow-md">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setView(item.view)}
            className={`flex flex-col items-center p-2 rounded ${currentView === item.view ? 'bg-blue-700' : ''}`}
          >
            <item.icon size={20} />
            <span className="text-xs mt-1">{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-blue-900 text-white min-h-screen">
        <div className="p-6 text-2xl font-bold flex items-center gap-2">
          <Trophy className="text-yellow-400" />
          <span>PingPong Pro</span>
        </div>
        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setView(item.view)}
              className={`flex items-center gap-3 w-full p-3 rounded-lg transition-colors ${
                currentView === item.view ? 'bg-blue-700 font-semibold' : 'hover:bg-blue-800'
              }`}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};
