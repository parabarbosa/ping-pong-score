import React, { useState, useEffect } from 'react';
import { Player } from '../types';
import { getPlayers, savePlayer, exportToCSV } from '../services/storageService';
import { Plus, Edit2, Download, Save } from 'lucide-react';

export const PlayerList: React.FC = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [formData, setFormData] = useState<{ name: string; photoUrl: string }>({ name: '', photoUrl: '' });

  useEffect(() => {
    loadPlayers();
  }, []);

  const loadPlayers = () => {
    setPlayers(getPlayers());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = isEditing ? { id: isEditing, ...formData } : formData;
    savePlayer(payload);
    setIsEditing(null);
    setFormData({ name: '', photoUrl: '' });
    loadPlayers();
  };

  const startEdit = (player: Player) => {
    setIsEditing(player.id);
    setFormData({ name: player.name, photoUrl: player.photoUrl });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Gestão de Jogadores</h2>
        <button
          onClick={exportToCSV}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          <Download size={18} /> Exportar CSV
        </button>
      </div>

      {/* Form */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold mb-4">{isEditing ? 'Editar Jogador' : 'Novo Jogador'}</h3>
        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
          <input
            type="text"
            placeholder="Nome do Jogador"
            value={formData.name}
            onChange={e => setFormData({ ...formData, name: e.target.value })}
            className="flex-1 border p-2 rounded"
            required
          />
          <input
            type="text"
            placeholder="URL da Foto (opcional)"
            value={formData.photoUrl}
            onChange={e => setFormData({ ...formData, photoUrl: e.target.value })}
            className="flex-1 border p-2 rounded"
          />
          <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 flex items-center justify-center gap-2">
            {isEditing ? <Save size={18} /> : <Plus size={18} />}
            {isEditing ? 'Guardar' : 'Adicionar'}
          </button>
          {isEditing && (
             <button type="button" onClick={() => { setIsEditing(null); setFormData({name: '', photoUrl: ''}); }} className="bg-gray-300 text-gray-700 px-4 py-2 rounded">
               Cancelar
             </button>
          )}
        </form>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {players.map(player => (
          <div key={player.id} className="bg-white p-4 rounded-lg shadow flex items-center gap-4">
            <img 
              src={player.photoUrl} 
              alt={player.name} 
              className="w-16 h-16 rounded-full object-cover bg-gray-200"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/150?text=User'; }}
            />
            <div className="flex-1">
              <h4 className="font-bold text-lg">{player.name}</h4>
              <p className="text-sm text-gray-500">Jogos: {player.stats.matchesPlayed} | Vitórias: {player.stats.matchesWon}</p>
            </div>
            <button onClick={() => startEdit(player)} className="text-gray-400 hover:text-blue-600">
              <Edit2 size={18} />
            </button>
          </div>
        ))}
        {players.length === 0 && (
          <p className="col-span-full text-center text-gray-500 py-8">Nenhum jogador registado. Adicione jogadores para começar.</p>
        )}
      </div>
    </div>
  );
};
