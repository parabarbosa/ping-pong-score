import { Player, MatchResult } from '../types';

const PLAYERS_KEY = 'pingpong_players';
const MATCHES_KEY = 'pingpong_matches';

// Helper to generate IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

export const getPlayers = (): Player[] => {
  const data = localStorage.getItem(PLAYERS_KEY);
  if (!data) return [];
  return JSON.parse(data);
};

export const savePlayer = (player: Partial<Player>): Player => {
  const players = getPlayers();
  if (player.id) {
    const index = players.findIndex(p => p.id === player.id);
    if (index !== -1) {
      players[index] = { ...players[index], ...player } as Player;
      localStorage.setItem(PLAYERS_KEY, JSON.stringify(players));
      return players[index];
    }
  }
  
  const newPlayer: Player = {
    id: generateId(),
    name: player.name || 'Novo Jogador',
    photoUrl: player.photoUrl || 'https://picsum.photos/200',
    stats: {
      matchesPlayed: 0,
      matchesWon: 0,
      matchesLost: 0,
      pointsWon: 0,
      pointsLost: 0,
    },
    ...player
  };
  
  players.push(newPlayer);
  localStorage.setItem(PLAYERS_KEY, JSON.stringify(players));
  return newPlayer;
};

export const deletePlayer = (id: string) => {
  const players = getPlayers().filter(p => p.id !== id);
  localStorage.setItem(PLAYERS_KEY, JSON.stringify(players));
};

export const getMatches = (): MatchResult[] => {
  const data = localStorage.getItem(MATCHES_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveMatch = (match: Omit<MatchResult, 'id' | 'date'>) => {
  const matches = getMatches();
  const newMatch: MatchResult = {
    ...match,
    id: generateId(),
    date: new Date().toISOString(),
  };
  matches.push(newMatch);
  localStorage.setItem(MATCHES_KEY, JSON.stringify(matches));

  // Update Player Stats
  const players = getPlayers();
  
  // Helper to update a single player's stats
  const updateStats = (pid: string, isWinner: boolean, pWon: number, pLost: number) => {
    const pIndex = players.findIndex(p => p.id === pid);
    if (pIndex !== -1) {
      players[pIndex].stats.matchesPlayed += 1;
      if (isWinner) players[pIndex].stats.matchesWon += 1;
      else players[pIndex].stats.matchesLost += 1;
      
      players[pIndex].stats.pointsWon += pWon;
      players[pIndex].stats.pointsLost += pLost;
    }
  };

  match.teamA.forEach(pid => updateStats(pid, match.winnerTeam === 'A', match.scoreA, match.scoreB));
  match.teamB.forEach(pid => updateStats(pid, match.winnerTeam === 'B', match.scoreB, match.scoreA));

  localStorage.setItem(PLAYERS_KEY, JSON.stringify(players));
};

export const exportToCSV = () => {
  const players = getPlayers();
  const matches = getMatches();

  let csvContent = "data:text/csv;charset=utf-8,";
  
  // Players Section
  csvContent += "JOGADORES\n";
  csvContent += "ID,Nome,Jogos,Vitorias,Derrotas,Pontos_Ganhos,Pontos_Perdidos\n";
  players.forEach(p => {
    csvContent += `${p.id},${p.name},${p.stats.matchesPlayed},${p.stats.matchesWon},${p.stats.matchesLost},${p.stats.pointsWon},${p.stats.pointsLost}\n`;
  });

  csvContent += "\nHISTORICO_JOGOS\n";
  csvContent += "Data,Tipo,EquipaA,EquipaB,ScoreA,ScoreB,Vencedor\n";
  matches.forEach(m => {
    csvContent += `${m.date},${m.type},"${m.teamA.join('|')}","${m.teamB.join('|')}",${m.scoreA},${m.scoreB},${m.winnerTeam}\n`;
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "pingpong_data.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
