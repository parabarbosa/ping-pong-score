import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { PlayerList } from './components/PlayerList';
import { Leaderboard } from './components/Leaderboard';
import { GameSetup } from './components/GameSetup';
import { MatchInterface } from './components/MatchInterface';
import { ViewState, GameConfig } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('MENU');
  const [activeGameConfig, setActiveGameConfig] = useState<GameConfig | null>(null);

  const handleStartGame = (config: GameConfig) => {
    setActiveGameConfig(config);
    setCurrentView('GAME');
  };

  const handleGameFinish = () => {
    setActiveGameConfig(null);
    setCurrentView('LEADERBOARD'); // Go to ranking after game
  };

  const renderContent = () => {
    switch (currentView) {
      case 'PLAYERS':
        return <PlayerList />;
      case 'LEADERBOARD':
        return <Leaderboard />;
      case 'GAME':
        return activeGameConfig ? (
          <MatchInterface config={activeGameConfig} onFinish={handleGameFinish} />
        ) : (
          <div>Erro: Nenhuma configuração de jogo encontrada.</div>
        );
      case 'SETUP_MODE':
      case 'MENU':
        return <GameSetup onStart={handleStartGame} onCancel={() => setCurrentView('PLAYERS')} />;
      default:
        return <GameSetup onStart={handleStartGame} onCancel={() => setCurrentView('PLAYERS')} />;
    }
  };

  return (
    <Layout currentView={currentView} setView={setCurrentView}>
      {renderContent()}
    </Layout>
  );
}

export default App;
