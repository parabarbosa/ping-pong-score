export interface Player {
  id: string;
  name: string;
  photoUrl: string;
  stats: {
    matchesPlayed: number;
    matchesWon: number;
    matchesLost: number;
    pointsWon: number;
    pointsLost: number;
  };
}

export enum MatchType {
  SINGLES = 'SINGLES',
  DOUBLES = 'DOUBLES',
}

export interface MatchResult {
  id: string;
  date: string;
  type: MatchType;
  teamA: string[]; // Player IDs
  teamB: string[]; // Player IDs
  scoreA: number;
  scoreB: number;
  winnerTeam: 'A' | 'B';
}

export interface GameConfig {
  type: MatchType;
  teamA: Player[];
  teamB: Player[];
  initialServerIndex: number; // Index within the global service order list
  serviceOrder: Player[]; // Flattened array of players in service rotation order
}

export type ViewState = 'MENU' | 'PLAYERS' | 'SETUP_MODE' | 'SETUP_SINGLES' | 'SETUP_DOUBLES' | 'GAME' | 'LEADERBOARD';
